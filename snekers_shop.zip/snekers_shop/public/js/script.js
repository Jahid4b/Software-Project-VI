// Redirect to homepage after login (handled by backend)
